#include <Arduino.h>

int tombol1 = 34;
int tombol2 = 35;
int tombol3 = 32;
int merah = 23;
int kuning = 22;
int hijau = 21;

void setup() {
  Serial.begin(115200);
  pinMode(tombol1, INPUT_PULLUP);
  pinMode(tombol2, INPUT_PULLUP);
  pinMode(tombol3, INPUT_PULLUP);
  pinMode(merah, OUTPUT);
  pinMode(kuning, OUTPUT);
  pinMode(hijau, OUTPUT);
}

void loop() {
  if (digitalRead(tombol1) == LOW) {
    while (digitalRead(tombol1) == LOW);
    delay(50);
    for (int i = 0; i < 5; i++) {
      digitalWrite(merah, HIGH);
      delay(500);
      digitalWrite(merah, LOW);
      delay(500);
    }
  }

  if (digitalRead(tombol2) == LOW) {
    while (digitalRead(tombol2) == LOW);
    delay(50);
    for (int i = 0; i < 5; i++) {
      digitalWrite(merah, HIGH);
      digitalWrite(hijau, LOW);
      delay(500);
      
      digitalWrite(merah, LOW);
      digitalWrite(hijau, HIGH);
      delay(500);
    }
    digitalWrite(merah, LOW);
    digitalWrite(hijau, LOW);
  }

  if (digitalRead(tombol3) == LOW) {
    while (digitalRead(tombol3) == LOW);
    delay(50);
    for (int i = 0; i < 5; i++) {
      digitalWrite(merah, HIGH);
      digitalWrite(kuning, LOW);
      digitalWrite(hijau, LOW);
      delay(500);
      
      digitalWrite(merah, LOW);
      digitalWrite(kuning, HIGH);
      digitalWrite(hijau, LOW);
      delay(500);
      
      digitalWrite(merah, LOW);
      digitalWrite(kuning, LOW);
      digitalWrite(hijau, HIGH);
      delay(500);
    }
    digitalWrite(merah, LOW);
    digitalWrite(kuning, LOW);
    digitalWrite(hijau, LOW);
  }
}
